import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FeaturedProducts from "@/components/FeaturedProducts";
import CategorySection from "@/components/CategorySection";
import PromoBar from "@/components/PromoBar";
import NewsletterSection from "@/components/NewsletterSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <PromoBar />
      <FeaturedProducts />
      <CategorySection />
      <NewsletterSection />
      <Footer />
    </div>
  );
};

export default Index;
