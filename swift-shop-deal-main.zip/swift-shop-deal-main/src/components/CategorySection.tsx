import categoryWomen from "@/assets/category-women.jpg";
import categoryMen from "@/assets/category-men.jpg";
import categoryAccessories from "@/assets/category-accessories.jpg";

const categories = [
  { name: "Women", image: categoryWomen },
  { name: "Men", image: categoryMen },
  { name: "Accessories", image: categoryAccessories },
];

const CategorySection = () => {
  return (
    <section className="py-20 lg:py-28 bg-secondary">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="text-center mb-14">
          <p className="text-accent text-sm font-medium tracking-[0.2em] uppercase mb-3">Browse</p>
          <h2 className="font-serif text-3xl lg:text-4xl font-semibold text-foreground">Shop by Category</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((cat) => (
            <a key={cat.name} href="#" className="group relative aspect-[4/3] overflow-hidden rounded-sm">
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
                width={800}
                height={600}
              />
              <div className="absolute inset-0 bg-foreground/30 group-hover:bg-foreground/40 transition-colors duration-500" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <h3 className="font-serif text-2xl lg:text-3xl font-semibold text-background mb-2">{cat.name}</h3>
                  <span className="text-background/80 text-sm font-medium tracking-wider uppercase border-b border-background/50 pb-0.5 group-hover:border-background transition-colors">
                    Explore
                  </span>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
