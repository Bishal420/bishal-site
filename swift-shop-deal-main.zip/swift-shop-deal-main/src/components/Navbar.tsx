import { useState } from "react";
import { ShoppingBag, Search, Menu, X, User } from "lucide-react";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Mobile menu toggle */}
          <button
            className="lg:hidden text-foreground"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          {/* Left nav links */}
          <div className="hidden lg:flex items-center gap-8">
            {["New Arrivals", "Women", "Men", "Accessories"].map((item) => (
              <a
                key={item}
                href="#"
                className="text-sm font-medium tracking-wide text-muted-foreground hover:text-foreground transition-colors duration-300"
              >
                {item}
              </a>
            ))}
          </div>

          {/* Logo */}
          <a href="/" className="font-serif text-2xl lg:text-3xl font-semibold tracking-tight text-foreground">
            MAISON
          </a>

          {/* Right icons */}
          <div className="flex items-center gap-5">
            <button className="hidden lg:block text-muted-foreground hover:text-foreground transition-colors" aria-label="Search">
              <Search size={20} />
            </button>
            <button className="hidden lg:block text-muted-foreground hover:text-foreground transition-colors" aria-label="Account">
              <User size={20} />
            </button>
            <button className="relative text-muted-foreground hover:text-foreground transition-colors" aria-label="Cart">
              <ShoppingBag size={20} />
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-accent text-accent-foreground text-[10px] font-semibold rounded-full flex items-center justify-center">
                3
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-background border-t border-border animate-fade-in">
          <div className="px-6 py-6 space-y-4">
            {["New Arrivals", "Women", "Men", "Accessories"].map((item) => (
              <a
                key={item}
                href="#"
                className="block text-base font-medium text-foreground hover:text-accent transition-colors"
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
