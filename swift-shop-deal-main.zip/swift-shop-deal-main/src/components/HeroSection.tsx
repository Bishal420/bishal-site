import heroImage from "@/assets/hero-lifestyle.jpg";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <section className="relative min-h-[85vh] lg:min-h-screen flex items-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Luxury fashion collection"
          className="w-full h-full object-cover"
          width={1920}
          height={1080}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/60 via-foreground/30 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-6 lg:px-12">
        <div className="max-w-xl animate-fade-in-up">
          <p className="text-primary-foreground/80 text-sm font-medium tracking-[0.25em] uppercase mb-4">
            Spring/Summer 2026
          </p>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-semibold text-primary-foreground leading-[1.1] mb-6">
            Timeless Elegance, Redefined
          </h1>
          <p className="text-primary-foreground/75 text-base lg:text-lg leading-relaxed mb-8 max-w-md">
            Discover our curated collection of luxury essentials crafted for the modern connoisseur.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button variant="hero" size="lg">
              Shop Collection
            </Button>
            <Button variant="heroOutline" size="lg">
              Explore More
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
