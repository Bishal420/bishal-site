import productBag from "@/assets/product-bag.jpg";
import productWatch from "@/assets/product-watch.jpg";
import productSunglasses from "@/assets/product-sunglasses.jpg";
import productShoes from "@/assets/product-shoes.jpg";
import productJewelry from "@/assets/product-jewelry.jpg";
import productScarf from "@/assets/product-scarf.jpg";
import { Heart } from "lucide-react";

const products = [
  { name: "Leather Tote Bag", price: "$485", image: productBag, tag: "New" },
  { name: "Gold Heritage Watch", price: "$1,250", image: productWatch, tag: "Bestseller" },
  { name: "Classic Sunglasses", price: "$320", image: productSunglasses },
  { name: "Minimal Sneakers", price: "$295", image: productShoes, tag: "New" },
  { name: "Pearl Chain Bracelet", price: "$180", image: productJewelry },
  { name: "Cashmere Scarf", price: "$215", image: productScarf },
];

const FeaturedProducts = () => {
  return (
    <section className="py-20 lg:py-28">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="text-center mb-14">
          <p className="text-accent text-sm font-medium tracking-[0.2em] uppercase mb-3">Curated Selection</p>
          <h2 className="font-serif text-3xl lg:text-4xl font-semibold text-foreground">Featured Products</h2>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-8">
          {products.map((product) => (
            <div key={product.name} className="group cursor-pointer">
              <div className="relative aspect-[4/5] overflow-hidden rounded-sm bg-secondary mb-4">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                  width={800}
                  height={1000}
                />
                {/* Wishlist */}
                <button className="absolute top-3 right-3 w-9 h-9 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-background" aria-label="Add to wishlist">
                  <Heart size={16} className="text-foreground" />
                </button>
                {/* Tag */}
                {product.tag && (
                  <span className="absolute top-3 left-3 bg-foreground text-background text-[10px] font-semibold tracking-wider uppercase px-3 py-1">
                    {product.tag}
                  </span>
                )}
                {/* Quick add */}
                <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
                  <button className="w-full bg-foreground/90 backdrop-blur-sm text-background text-sm font-medium py-2.5 rounded-sm hover:bg-foreground transition-colors">
                    Quick Add
                  </button>
                </div>
              </div>
              <h3 className="text-sm lg:text-base font-medium text-foreground group-hover:text-accent transition-colors">
                {product.name}
              </h3>
              <p className="text-sm text-muted-foreground mt-1">{product.price}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
