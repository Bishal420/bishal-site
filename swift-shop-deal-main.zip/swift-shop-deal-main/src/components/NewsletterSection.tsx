import { useState } from "react";
import { Button } from "@/components/ui/button";

const NewsletterSection = () => {
  const [email, setEmail] = useState("");

  return (
    <section className="py-20 lg:py-28 bg-foreground">
      <div className="container mx-auto px-6 lg:px-12 text-center">
        <h2 className="font-serif text-3xl lg:text-4xl font-semibold text-background mb-4">
          Join the Maison
        </h2>
        <p className="text-background/60 text-base max-w-md mx-auto mb-8">
          Subscribe for exclusive access to new collections, private sales, and styling inspiration.
        </p>
        <form
          onSubmit={(e) => e.preventDefault()}
          className="flex flex-col sm:flex-row items-center gap-3 max-w-md mx-auto"
        >
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Your email address"
            className="flex-1 w-full px-4 py-3 bg-background/10 border border-background/20 text-background placeholder:text-background/40 text-sm rounded-sm focus:outline-none focus:border-background/50 transition-colors"
          />
          <Button variant="newsletter" size="lg" type="submit">
            Subscribe
          </Button>
        </form>
      </div>
    </section>
  );
};

export default NewsletterSection;
