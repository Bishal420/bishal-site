const footerLinks = {
  Shop: ["New Arrivals", "Women", "Men", "Accessories", "Sale"],
  Help: ["Contact Us", "FAQs", "Shipping", "Returns", "Size Guide"],
  Company: ["About Us", "Careers", "Press", "Sustainability"],
};

const Footer = () => (
  <footer className="bg-foreground pt-16 pb-8">
    <div className="container mx-auto px-6 lg:px-12">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
        {/* Brand */}
        <div className="col-span-2 md:col-span-1">
          <h3 className="font-serif text-2xl font-semibold text-background mb-4">MAISON</h3>
          <p className="text-background/50 text-sm leading-relaxed max-w-xs">
            Crafting timeless luxury for the modern world since 2020.
          </p>
        </div>

        {/* Links */}
        {Object.entries(footerLinks).map(([title, links]) => (
          <div key={title}>
            <h4 className="text-background text-sm font-semibold tracking-wider uppercase mb-4">{title}</h4>
            <ul className="space-y-2.5">
              {links.map((link) => (
                <li key={link}>
                  <a href="#" className="text-background/50 text-sm hover:text-background transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-background/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-background/40 text-xs">© 2026 Maison. All rights reserved.</p>
        <div className="flex items-center gap-6">
          {["Privacy Policy", "Terms of Service", "Cookie Policy"].map((item) => (
            <a key={item} href="#" className="text-background/40 text-xs hover:text-background/70 transition-colors">
              {item}
            </a>
          ))}
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
