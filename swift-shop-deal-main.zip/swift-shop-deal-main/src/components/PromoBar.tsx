import { Truck, RotateCcw, Shield, Gift } from "lucide-react";

const perks = [
  { icon: Truck, title: "Free Shipping", desc: "On orders over $200" },
  { icon: RotateCcw, title: "Easy Returns", desc: "30-day return policy" },
  { icon: Shield, title: "Secure Payment", desc: "100% protected" },
  { icon: Gift, title: "Gift Wrapping", desc: "Premium packaging" },
];

const PromoBar = () => (
  <section className="py-16 border-t border-b border-border">
    <div className="container mx-auto px-6 lg:px-12">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
        {perks.map((perk) => (
          <div key={perk.title} className="text-center">
            <perk.icon size={28} className="mx-auto mb-3 text-accent" strokeWidth={1.5} />
            <h4 className="text-sm font-semibold text-foreground mb-1">{perk.title}</h4>
            <p className="text-xs text-muted-foreground">{perk.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default PromoBar;
